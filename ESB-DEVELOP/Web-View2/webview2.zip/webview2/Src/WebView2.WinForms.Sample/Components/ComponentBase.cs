﻿
namespace MtrDev.WebView2.WinForms.Sample.Components
{
    public abstract class ComponentBase
    {
        public abstract void CleanUp();
    }
}
