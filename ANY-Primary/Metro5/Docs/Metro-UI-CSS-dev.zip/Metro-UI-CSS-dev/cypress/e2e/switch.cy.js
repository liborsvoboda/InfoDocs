
describe('Test switch.html', () => {
  it('passes', () => {
    cy.visit('tests/switch.html')
  })
})
