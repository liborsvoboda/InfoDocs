
describe('Test html-container.html', () => {
  it('passes', () => {
    cy.visit('tests/html-container.html')
  })
})
