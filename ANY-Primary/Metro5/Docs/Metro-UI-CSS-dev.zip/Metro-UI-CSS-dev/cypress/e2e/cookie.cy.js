
describe('Test cookie.html', () => {
  it('passes', () => {
    cy.visit('tests/cookie.html')
  })
})
