
describe('Test select-options.html', () => {
  it('passes', () => {
    cy.visit('tests/select-options.html')
  })
})
