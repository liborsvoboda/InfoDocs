
describe('Test hotkey.html', () => {
  it('passes', () => {
    cy.visit('tests/hotkey.html')
  })
})
