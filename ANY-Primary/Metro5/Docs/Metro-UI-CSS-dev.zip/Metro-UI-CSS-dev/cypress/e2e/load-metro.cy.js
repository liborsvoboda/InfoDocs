
describe('Test load-metro.html', () => {
  it('passes', () => {
    cy.visit('tests/load-metro.html')
  })
})
