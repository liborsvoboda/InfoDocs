
describe('Test scrollbar.html', () => {
  it('passes', () => {
    cy.visit('tests/scrollbar.html')
  })
})
