
describe('Test calendar.html', () => {
  it('passes', () => {
    cy.visit('tests/calendar.html')
  })
})
