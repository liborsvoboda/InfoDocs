
describe('Test storage.html', () => {
  it('passes', () => {
    cy.visit('tests/storage.html')
  })
})
