
describe('Test listview.html', () => {
  it('passes', () => {
    cy.visit('tests/listview.html')
  })
})
