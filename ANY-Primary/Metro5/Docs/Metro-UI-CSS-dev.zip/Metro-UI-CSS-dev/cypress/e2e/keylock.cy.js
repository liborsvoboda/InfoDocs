
describe('Test keylock.html', () => {
  it('passes', () => {
    cy.visit('tests/keylock.html')
  })
})
