
describe('Test viewport-check.html', () => {
  it('passes', () => {
    cy.visit('tests/viewport-check.html')
  })
})
