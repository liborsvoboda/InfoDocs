
describe('Test button-group.html', () => {
  it('passes', () => {
    cy.visit('tests/button-group.html')
  })
})
