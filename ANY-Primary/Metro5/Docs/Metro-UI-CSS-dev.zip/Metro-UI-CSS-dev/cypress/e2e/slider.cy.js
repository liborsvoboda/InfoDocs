
describe('Test slider.html', () => {
  it('passes', () => {
    cy.visit('tests/slider.html')
  })
})
