
describe('Test panel.html', () => {
  it('passes', () => {
    cy.visit('tests/panel.html')
  })
})
