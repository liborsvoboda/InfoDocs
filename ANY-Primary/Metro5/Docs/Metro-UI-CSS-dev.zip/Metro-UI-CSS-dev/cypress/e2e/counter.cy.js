
describe('Test counter.html', () => {
  it('passes', () => {
    cy.visit('tests/counter.html')
  })
})
