
describe('Test adblock.html', () => {
  it('passes', () => {
    cy.visit('tests/adblock.html')
  })
})
