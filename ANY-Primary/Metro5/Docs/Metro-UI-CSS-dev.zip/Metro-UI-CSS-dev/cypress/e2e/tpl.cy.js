
describe('Test tpl.html', () => {
  it('passes', () => {
    cy.visit('tests/tpl.html')
  })
})
