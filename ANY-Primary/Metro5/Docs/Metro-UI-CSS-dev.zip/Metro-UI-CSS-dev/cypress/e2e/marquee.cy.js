
describe('Test marquee.html', () => {
  it('passes', () => {
    cy.visit('tests/marquee.html')
  })
})
