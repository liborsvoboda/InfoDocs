
describe('Test dropdown.html', () => {
  it('passes', () => {
    cy.visit('tests/dropdown.html')
  })
})
