
describe('Test clock.html', () => {
  it('passes', () => {
    cy.visit('tests/clock.html')
  })
})
