
describe('Test cookie-disclaimer.html', () => {
  it('passes', () => {
    cy.visit('tests/cookie-disclaimer.html')
  })
})
