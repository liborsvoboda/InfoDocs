
describe('Test tile.html', () => {
  it('passes', () => {
    cy.visit('tests/tile.html')
  })
})
