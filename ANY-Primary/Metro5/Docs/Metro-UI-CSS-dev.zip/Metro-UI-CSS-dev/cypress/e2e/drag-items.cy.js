
describe('Test drag-items.html', () => {
  it('passes', () => {
    cy.visit('tests/drag-items.html')
  })
})
