
describe('Test wizard.html', () => {
  it('passes', () => {
    cy.visit('tests/wizard.html')
  })
})
