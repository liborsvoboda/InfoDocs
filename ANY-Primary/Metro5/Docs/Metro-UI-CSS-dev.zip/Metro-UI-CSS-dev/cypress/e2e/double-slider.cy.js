
describe('Test double-slider.html', () => {
  it('passes', () => {
    cy.visit('tests/double-slider.html')
  })
})
