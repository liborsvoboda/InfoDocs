
describe('Test calendar-picker.html', () => {
  it('passes', () => {
    cy.visit('tests/calendar-picker.html')
  })
})
