
describe('Test audio-player.html', () => {
  it('passes', () => {
    cy.visit('tests/audio-player.html')
  })
})
