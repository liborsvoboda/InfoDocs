
describe('Test carousel.html', () => {
  it('passes', () => {
    cy.visit('tests/carousel.html')
  })
})
