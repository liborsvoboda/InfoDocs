
describe('Test draggable.html', () => {
  it('passes', () => {
    cy.visit('tests/draggable.html')
  })
})
