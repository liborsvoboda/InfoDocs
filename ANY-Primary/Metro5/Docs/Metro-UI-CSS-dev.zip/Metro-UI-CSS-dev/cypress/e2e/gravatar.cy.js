
describe('Test gravatar.html', () => {
  it('passes', () => {
    cy.visit('tests/gravatar.html')
  })
})
