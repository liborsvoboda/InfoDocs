
describe('Test image-magnifier.html', () => {
  it('passes', () => {
    cy.visit('tests/image-magnifier.html')
  })
})
