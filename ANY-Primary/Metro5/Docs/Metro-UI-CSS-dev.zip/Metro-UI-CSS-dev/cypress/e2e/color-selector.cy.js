
describe('Test color-selector.html', () => {
  it('passes', () => {
    cy.visit('tests/color-selector.html')
  })
})
