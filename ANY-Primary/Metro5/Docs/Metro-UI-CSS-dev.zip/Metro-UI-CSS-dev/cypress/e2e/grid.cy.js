
describe('Test grid.html', () => {
  it('passes', () => {
    cy.visit('tests/grid.html')
  })
})
