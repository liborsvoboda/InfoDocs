
describe('Test tokenizer.html', () => {
  it('passes', () => {
    cy.visit('tests/tokenizer.html')
  })
})
