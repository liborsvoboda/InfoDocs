
describe('Test tabs.html', () => {
  it('passes', () => {
    cy.visit('tests/tabs.html')
  })
})
