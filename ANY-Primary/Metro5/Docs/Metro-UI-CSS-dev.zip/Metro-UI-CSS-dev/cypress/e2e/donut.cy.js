
describe('Test donut.html', () => {
  it('passes', () => {
    cy.visit('tests/donut.html')
  })
})
