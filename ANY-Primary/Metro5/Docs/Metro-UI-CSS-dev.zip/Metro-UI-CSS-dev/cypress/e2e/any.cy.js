
describe('Test any.html', () => {
  it('passes', () => {
    cy.visit('tests/any.html')
  })
})
