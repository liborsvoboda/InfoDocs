
describe('Test hint.html', () => {
  it('passes', () => {
    cy.visit('tests/hint.html')
  })
})
