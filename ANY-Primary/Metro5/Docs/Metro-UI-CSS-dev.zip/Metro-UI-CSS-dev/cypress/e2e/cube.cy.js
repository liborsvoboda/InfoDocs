
describe('Test cube.html', () => {
  it('passes', () => {
    cy.visit('tests/cube.html')
  })
})
