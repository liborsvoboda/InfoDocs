
describe('Test list.html', () => {
  it('passes', () => {
    cy.visit('tests/list.html')
  })
})
