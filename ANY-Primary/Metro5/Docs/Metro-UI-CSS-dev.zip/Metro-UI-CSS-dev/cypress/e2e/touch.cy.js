
describe('Test touch.html', () => {
  it('passes', () => {
    cy.visit('tests/touch.html')
  })
})
