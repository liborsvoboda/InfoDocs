
describe('Test resizable.html', () => {
  it('passes', () => {
    cy.visit('tests/resizable.html')
  })
})
