
describe('Test spinner.html', () => {
  it('passes', () => {
    cy.visit('tests/spinner.html')
  })
})
