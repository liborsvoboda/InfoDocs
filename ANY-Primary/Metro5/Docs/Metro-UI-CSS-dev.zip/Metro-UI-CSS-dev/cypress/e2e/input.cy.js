
describe('Test input.html', () => {
  it('passes', () => {
    cy.visit('tests/input.html')
  })
})
