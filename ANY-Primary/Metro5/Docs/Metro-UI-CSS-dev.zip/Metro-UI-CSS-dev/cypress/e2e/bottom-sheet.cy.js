
describe('Test bottom-sheet.html', () => {
  it('passes', () => {
    cy.visit('tests/bottom-sheet.html')
  })
})
