
describe('Test dialog.html', () => {
  it('passes', () => {
    cy.visit('tests/dialog.html')
  })
})
