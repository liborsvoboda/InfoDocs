
describe('Test new-year.html', () => {
  it('passes', () => {
    cy.visit('tests/new-year.html')
  })
})
