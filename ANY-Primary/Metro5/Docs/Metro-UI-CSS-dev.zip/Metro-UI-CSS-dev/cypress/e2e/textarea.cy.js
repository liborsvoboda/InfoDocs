
describe('Test textarea.html', () => {
  it('passes', () => {
    cy.visit('tests/textarea.html')
  })
})
