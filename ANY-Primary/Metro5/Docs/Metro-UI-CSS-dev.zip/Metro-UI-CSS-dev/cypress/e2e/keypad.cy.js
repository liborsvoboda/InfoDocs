
describe('Test keypad.html', () => {
  it('passes', () => {
    cy.visit('tests/keypad.html')
  })
})
