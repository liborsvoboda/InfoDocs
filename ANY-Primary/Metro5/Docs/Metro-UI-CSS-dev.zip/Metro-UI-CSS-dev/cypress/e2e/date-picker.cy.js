
describe('Test date-picker.html', () => {
  it('passes', () => {
    cy.visit('tests/date-picker.html')
  })
})
