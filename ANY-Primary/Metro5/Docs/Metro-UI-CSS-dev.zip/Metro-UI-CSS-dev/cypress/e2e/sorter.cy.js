
describe('Test sorter.html', () => {
  it('passes', () => {
    cy.visit('tests/sorter.html')
  })
})
