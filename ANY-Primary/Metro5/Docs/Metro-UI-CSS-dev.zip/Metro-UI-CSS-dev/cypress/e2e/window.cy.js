
describe('Test window.html', () => {
  it('passes', () => {
    cy.visit('tests/window.html')
  })
})
