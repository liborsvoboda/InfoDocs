
describe('Test navview.html', () => {
  it('passes', () => {
    cy.visit('tests/navview.html')
  })
})
