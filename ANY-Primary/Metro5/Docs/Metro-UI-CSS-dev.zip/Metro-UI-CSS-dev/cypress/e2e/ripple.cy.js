
describe('Test ripple.html', () => {
  it('passes', () => {
    cy.visit('tests/ripple.html')
  })
})
