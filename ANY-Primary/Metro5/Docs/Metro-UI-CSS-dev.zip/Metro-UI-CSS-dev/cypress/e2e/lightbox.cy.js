
describe('Test lightbox.html', () => {
  it('passes', () => {
    cy.visit('tests/lightbox.html')
  })
})
