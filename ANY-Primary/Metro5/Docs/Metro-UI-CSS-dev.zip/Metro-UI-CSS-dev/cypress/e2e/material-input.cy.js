
describe('Test material-input.html', () => {
  it('passes', () => {
    cy.visit('tests/material-input.html')
  })
})
