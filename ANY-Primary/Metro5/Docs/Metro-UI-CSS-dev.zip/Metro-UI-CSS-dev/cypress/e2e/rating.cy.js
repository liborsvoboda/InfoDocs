
describe('Test rating.html', () => {
  it('passes', () => {
    cy.visit('tests/rating.html')
  })
})
