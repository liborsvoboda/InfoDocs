
describe('Test stepper.html', () => {
  it('passes', () => {
    cy.visit('tests/stepper.html')
  })
})
