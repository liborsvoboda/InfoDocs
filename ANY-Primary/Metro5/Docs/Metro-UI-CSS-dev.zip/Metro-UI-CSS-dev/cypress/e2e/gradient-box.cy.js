
describe('Test gradient-box.html', () => {
  it('passes', () => {
    cy.visit('tests/gradient-box.html')
  })
})
