
describe('Test pagination.html', () => {
  it('passes', () => {
    cy.visit('tests/pagination.html')
  })
})
