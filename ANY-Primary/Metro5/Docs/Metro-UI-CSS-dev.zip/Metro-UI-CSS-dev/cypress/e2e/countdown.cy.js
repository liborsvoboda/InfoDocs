
describe('Test countdown.html', () => {
  it('passes', () => {
    cy.visit('tests/countdown.html')
  })
})
