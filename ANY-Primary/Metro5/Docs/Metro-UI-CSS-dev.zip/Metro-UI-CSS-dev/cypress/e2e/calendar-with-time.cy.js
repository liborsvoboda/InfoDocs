
describe('Test calendar-with-time.html', () => {
  it('passes', () => {
    cy.visit('tests/calendar-with-time.html')
  })
})
