
describe('Test popover.html', () => {
  it('passes', () => {
    cy.visit('tests/popover.html')
  })
})
