
describe('Test image-compare.html', () => {
  it('passes', () => {
    cy.visit('tests/image-compare.html')
  })
})
