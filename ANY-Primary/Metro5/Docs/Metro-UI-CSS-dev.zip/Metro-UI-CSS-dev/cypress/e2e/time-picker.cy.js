
describe('Test time-picker.html', () => {
  it('passes', () => {
    cy.visit('tests/time-picker.html')
  })
})
