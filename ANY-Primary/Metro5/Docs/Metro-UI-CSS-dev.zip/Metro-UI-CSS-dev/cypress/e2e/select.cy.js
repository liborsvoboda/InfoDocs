
describe('Test select.html', () => {
  it('passes', () => {
    cy.visit('tests/select.html')
  })
})
