
describe('Test toast.html', () => {
  it('passes', () => {
    cy.visit('tests/toast.html')
  })
})
