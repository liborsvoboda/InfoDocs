
describe('Test streamer.html', () => {
  it('passes', () => {
    cy.visit('tests/streamer.html')
  })
})
