
describe('Test image-box.html', () => {
  it('passes', () => {
    cy.visit('tests/image-box.html')
  })
})
