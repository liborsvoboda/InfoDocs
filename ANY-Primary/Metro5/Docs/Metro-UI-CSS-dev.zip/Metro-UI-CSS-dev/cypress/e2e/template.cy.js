
describe('Test template.html', () => {
  it('passes', () => {
    cy.visit('tests/template.html')
  })
})
