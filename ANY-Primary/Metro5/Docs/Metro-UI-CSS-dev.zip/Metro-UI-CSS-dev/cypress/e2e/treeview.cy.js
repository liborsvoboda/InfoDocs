
describe('Test treeview.html', () => {
  it('passes', () => {
    cy.visit('tests/treeview.html')
  })
})
