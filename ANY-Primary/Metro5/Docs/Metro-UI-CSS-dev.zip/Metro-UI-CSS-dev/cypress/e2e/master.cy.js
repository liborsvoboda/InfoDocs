
describe('Test master.html', () => {
  it('passes', () => {
    cy.visit('tests/master.html')
  })
})
