
describe('Test activity.html', () => {
  it('passes', () => {
    cy.visit('tests/activity.html')
  })
})
