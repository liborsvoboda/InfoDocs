
describe('Test table.html', () => {
  it('passes', () => {
    cy.visit('tests/table.html')
  })
})
