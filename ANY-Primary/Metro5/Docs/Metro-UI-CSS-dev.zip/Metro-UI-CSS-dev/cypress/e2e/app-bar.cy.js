
describe('Test app-bar.html', () => {
  it('passes', () => {
    cy.visit('tests/app-bar.html')
  })
})
