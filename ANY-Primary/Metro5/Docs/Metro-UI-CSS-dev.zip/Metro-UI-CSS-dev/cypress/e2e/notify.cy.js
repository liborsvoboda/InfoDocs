
describe('Test notify.html', () => {
  it('passes', () => {
    cy.visit('tests/notify.html')
  })
})
