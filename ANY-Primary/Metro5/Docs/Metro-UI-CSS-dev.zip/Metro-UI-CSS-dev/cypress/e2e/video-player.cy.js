
describe('Test video-player.html', () => {
  it('passes', () => {
    cy.visit('tests/video-player.html')
  })
})
