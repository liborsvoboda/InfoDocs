
describe('Test colors.html', () => {
  it('passes', () => {
    cy.visit('tests/colors.html')
  })
})
