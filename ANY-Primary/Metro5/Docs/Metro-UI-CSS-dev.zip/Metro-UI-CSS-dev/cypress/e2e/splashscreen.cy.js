
describe('Test splashscreen.html', () => {
  it('passes', () => {
    cy.visit('tests/splashscreen.html')
  })
})
