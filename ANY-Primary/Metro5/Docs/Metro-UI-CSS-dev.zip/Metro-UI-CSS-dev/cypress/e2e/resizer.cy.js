
describe('Test resizer.html', () => {
  it('passes', () => {
    cy.visit('tests/resizer.html')
  })
})
