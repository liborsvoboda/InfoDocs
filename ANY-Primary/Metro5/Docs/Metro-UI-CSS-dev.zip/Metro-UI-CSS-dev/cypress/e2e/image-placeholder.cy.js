
describe('Test image-placeholder.html', () => {
  it('passes', () => {
    cy.visit('tests/image-placeholder.html')
  })
})
