
describe('Test radio.html', () => {
  it('passes', () => {
    cy.visit('tests/radio.html')
  })
})
