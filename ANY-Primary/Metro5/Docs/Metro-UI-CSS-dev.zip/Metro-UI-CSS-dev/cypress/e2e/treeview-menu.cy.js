
describe('Test treeview-menu.html', () => {
  it('passes', () => {
    cy.visit('tests/treeview-menu.html')
  })
})
