
describe('Test double-select-box.html', () => {
  it('passes', () => {
    cy.visit('tests/double-select-box.html')
  })
})
