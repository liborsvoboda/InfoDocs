
describe('Test tag-input.html', () => {
  it('passes', () => {
    cy.visit('tests/tag-input.html')
  })
})
