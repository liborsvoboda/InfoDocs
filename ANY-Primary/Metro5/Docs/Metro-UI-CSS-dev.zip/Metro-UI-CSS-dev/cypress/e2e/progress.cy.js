
describe('Test progress.html', () => {
  it('passes', () => {
    cy.visit('tests/progress.html')
  })
})
