
describe('Test accordion.html', () => {
  it('passes', () => {
    cy.visit('tests/accordion.html')
  })
})
