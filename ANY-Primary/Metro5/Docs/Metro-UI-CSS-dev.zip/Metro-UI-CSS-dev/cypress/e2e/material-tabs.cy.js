
describe('Test material-tabs.html', () => {
  it('passes', () => {
    cy.visit('tests/material-tabs.html')
  })
})
