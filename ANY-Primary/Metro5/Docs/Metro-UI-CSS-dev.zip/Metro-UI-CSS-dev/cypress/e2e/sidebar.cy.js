
describe('Test sidebar.html', () => {
  it('passes', () => {
    cy.visit('tests/sidebar.html')
  })
})
