
describe('Test validator.html', () => {
  it('passes', () => {
    cy.visit('tests/validator.html')
  })
})
