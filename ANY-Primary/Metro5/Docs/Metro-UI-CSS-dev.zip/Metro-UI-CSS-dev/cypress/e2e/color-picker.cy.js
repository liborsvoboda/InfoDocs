
describe('Test color-picker.html', () => {
  it('passes', () => {
    cy.visit('tests/color-picker.html')
  })
})
