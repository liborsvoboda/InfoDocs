
describe('Test info-box.html', () => {
  it('passes', () => {
    cy.visit('tests/info-box.html')
  })
})
