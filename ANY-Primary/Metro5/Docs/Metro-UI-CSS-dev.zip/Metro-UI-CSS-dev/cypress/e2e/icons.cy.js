
describe('Test icons.html', () => {
  it('passes', () => {
    cy.visit('tests/icons.html')
  })
})
