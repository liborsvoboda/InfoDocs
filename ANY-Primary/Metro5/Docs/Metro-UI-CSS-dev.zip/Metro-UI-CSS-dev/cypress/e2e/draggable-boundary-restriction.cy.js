
describe('Test draggable-boundary-restriction.html', () => {
  it('passes', () => {
    cy.visit('tests/draggable-boundary-restriction.html')
  })
})
