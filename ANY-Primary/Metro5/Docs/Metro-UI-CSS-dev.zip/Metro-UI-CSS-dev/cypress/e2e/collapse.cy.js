
describe('Test collapse.html', () => {
  it('passes', () => {
    cy.visit('tests/collapse.html')
  })
})
