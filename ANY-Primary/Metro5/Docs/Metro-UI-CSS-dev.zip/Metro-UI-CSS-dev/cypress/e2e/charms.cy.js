
describe('Test charms.html', () => {
  it('passes', () => {
    cy.visit('tests/charms.html')
  })
})
