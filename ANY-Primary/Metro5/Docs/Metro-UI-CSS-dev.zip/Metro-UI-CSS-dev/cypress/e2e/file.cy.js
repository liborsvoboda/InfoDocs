
describe('Test file.html', () => {
  it('passes', () => {
    cy.visit('tests/file.html')
  })
})
