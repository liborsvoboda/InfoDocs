
describe('Test audio-button.html', () => {
  it('passes', () => {
    cy.visit('tests/audio-button.html')
  })
})
