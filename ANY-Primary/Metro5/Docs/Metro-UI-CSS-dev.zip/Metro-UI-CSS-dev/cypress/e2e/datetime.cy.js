
describe('Test datetime.html', () => {
  it('passes', () => {
    cy.visit('tests/datetime.html')
  })
})
