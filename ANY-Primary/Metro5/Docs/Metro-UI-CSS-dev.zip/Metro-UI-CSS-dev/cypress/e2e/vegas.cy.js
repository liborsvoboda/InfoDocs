
describe('Test vegas.html', () => {
  it('passes', () => {
    cy.visit('tests/vegas.html')
  })
})
