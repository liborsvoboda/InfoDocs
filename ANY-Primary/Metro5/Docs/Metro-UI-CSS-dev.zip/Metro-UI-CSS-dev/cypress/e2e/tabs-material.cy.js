
describe('Test tabs-material.html', () => {
  it('passes', () => {
    cy.visit('tests/tabs-material.html')
  })
})
