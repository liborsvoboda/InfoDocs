
describe('Test splitter.html', () => {
  it('passes', () => {
    cy.visit('tests/splitter.html')
  })
})
