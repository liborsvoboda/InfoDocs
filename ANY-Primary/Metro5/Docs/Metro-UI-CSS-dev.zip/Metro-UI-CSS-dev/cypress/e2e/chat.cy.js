
describe('Test chat.html', () => {
  it('passes', () => {
    cy.visit('tests/chat.html')
  })
})
