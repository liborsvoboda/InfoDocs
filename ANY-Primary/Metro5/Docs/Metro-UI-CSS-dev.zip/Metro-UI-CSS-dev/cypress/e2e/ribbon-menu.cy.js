
describe('Test ribbon-menu.html', () => {
  it('passes', () => {
    cy.visit('tests/ribbon-menu.html')
  })
})
