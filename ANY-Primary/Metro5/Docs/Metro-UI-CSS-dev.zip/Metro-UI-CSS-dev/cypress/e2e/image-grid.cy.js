
describe('Test image-grid.html', () => {
  it('passes', () => {
    cy.visit('tests/image-grid.html')
  })
})
