
describe('Test input-mask.html', () => {
  it('passes', () => {
    cy.visit('tests/input-mask.html')
  })
})
