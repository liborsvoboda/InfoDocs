
describe('Test button.html', () => {
  it('passes', () => {
    cy.visit('tests/button.html')
  })
})
