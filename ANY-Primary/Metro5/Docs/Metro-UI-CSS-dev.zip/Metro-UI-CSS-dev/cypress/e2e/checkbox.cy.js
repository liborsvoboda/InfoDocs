
describe('Test checkbox.html', () => {
  it('passes', () => {
    cy.visit('tests/checkbox.html')
  })
})
