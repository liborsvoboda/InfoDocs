
describe('Test calendar-wide.html', () => {
  it('passes', () => {
    cy.visit('tests/calendar-wide.html')
  })
})
