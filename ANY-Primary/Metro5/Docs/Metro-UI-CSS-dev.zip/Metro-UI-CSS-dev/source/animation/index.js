import {Animation} from "@olton/animation";

globalThis.Animation = Animation
