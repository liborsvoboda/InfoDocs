import "../cookie"
import "./cookie-disclaimer.js"
import "./cookie-disclaimer.less"