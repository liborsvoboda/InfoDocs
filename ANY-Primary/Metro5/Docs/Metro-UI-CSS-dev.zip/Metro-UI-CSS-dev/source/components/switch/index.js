import "../input-common"
import "./switch.js"
import "./switch.less"