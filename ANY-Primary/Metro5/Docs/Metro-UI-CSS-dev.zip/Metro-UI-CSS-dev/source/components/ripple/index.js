import "../../farbe"
import "./ripple.js"
import "./ripple.less"