import "../input-common"
import "./keypad.js"
import "./keypad.less"