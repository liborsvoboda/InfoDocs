import "./slider.js"
import "./slider.less"