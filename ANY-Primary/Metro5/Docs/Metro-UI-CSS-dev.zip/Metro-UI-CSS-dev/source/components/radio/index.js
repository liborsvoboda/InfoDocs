import "../input-common"
import "./radio.js"
import "./radio.less"