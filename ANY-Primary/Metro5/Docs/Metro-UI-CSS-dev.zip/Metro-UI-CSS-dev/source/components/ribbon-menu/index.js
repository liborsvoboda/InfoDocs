import "./ribbon-menu.js"
import "./ribbon-menu.less"