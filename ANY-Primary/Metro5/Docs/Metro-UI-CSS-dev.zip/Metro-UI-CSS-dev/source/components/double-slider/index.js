import "../slider"
import "./double-slider.js"