import "./image-magnifier.js"
import "./image-magnifier.less"