import "../../farbe"
import "../hamburger"
import "./tabs.js"
import "./tabs.less"