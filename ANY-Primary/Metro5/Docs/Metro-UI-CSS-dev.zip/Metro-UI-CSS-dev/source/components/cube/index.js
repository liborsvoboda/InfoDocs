import "../../farbe"
import "./cube.js"
import "./cube.less"