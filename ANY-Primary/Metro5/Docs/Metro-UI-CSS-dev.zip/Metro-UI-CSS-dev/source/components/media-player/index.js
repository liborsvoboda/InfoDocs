import "../default-icons"
import "./media-player.less"