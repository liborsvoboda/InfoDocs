import "./pagecontrol.js"
import "./pagecontrol.less"