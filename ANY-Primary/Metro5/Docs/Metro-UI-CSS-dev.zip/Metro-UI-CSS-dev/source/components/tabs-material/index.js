import "./tabs-material.js"
import "./tabs-material.less"