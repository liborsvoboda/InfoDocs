import "../../farbe"
import "../colors"
import "./info-box.js"
import "./info-box.less"