import "./splitter.js"
import "./splitter.less"