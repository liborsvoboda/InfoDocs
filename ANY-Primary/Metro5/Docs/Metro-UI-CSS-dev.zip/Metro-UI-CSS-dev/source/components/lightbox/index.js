import "../button"
import "../default-icons"
import "./lightbox.js"
import "./lightbox.less"