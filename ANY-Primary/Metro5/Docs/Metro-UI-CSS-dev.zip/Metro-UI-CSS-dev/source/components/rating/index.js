import "../../farbe"
import "./rating.js"
import "./rating.less"