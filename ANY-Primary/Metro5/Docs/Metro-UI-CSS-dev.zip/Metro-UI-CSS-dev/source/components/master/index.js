import "../default-icons"
import "./master.js"
import "./master.less"