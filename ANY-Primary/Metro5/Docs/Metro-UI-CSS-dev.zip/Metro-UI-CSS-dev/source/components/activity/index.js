import "../dialog"
import "./activity.js"
import "./activity.less"