import "./image-compare.js"
import "./image-compare.less"