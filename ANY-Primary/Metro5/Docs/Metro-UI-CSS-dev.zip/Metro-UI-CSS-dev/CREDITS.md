### Copyright 

2012-2020 © Copyright. Serhii Pimenov. All Rights Reserved.
Created by Serhii Pimenov.

### Credits
- Styles created using the [less](http://lesscss.org) preprocessor by  [Alexis Sellier](https://github.com/cloudhead)
- preCode by Leon Sorokin [preCode](https://github.com/leeoniya/preCode.js)
- strftime by Tom Doan [strftime](https://github.com/thdoan/strftime)
- function b64toBlob by [Jeremy Banks](http://stackoverflow.com/users/1114/jeremy-banks)
- Date.getWeek by [Nick Baicoianu](http://www.epoch-calendar.com)
- Swipe component based on [Matt Bryson](https://github.com/mattbryson/TouchSwipe-Jquery-Plugin)  TouchSwipe plugin
- Data source processor by [jQuery](https://jquery.com)
- All who brought something good 
